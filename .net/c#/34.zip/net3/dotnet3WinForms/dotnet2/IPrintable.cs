﻿namespace dotnet2;

public interface IPrintable
{
	void Print();
}
